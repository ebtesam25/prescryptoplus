import os
import pymongo
import json
import time
import requests

def hederainsert(datain):

    url = "https://woodle.ngrok.io/healthRecord"

    payload = json.dumps(datain)
    headers = {
        'Content-Type': "application/json",
        'cache-control': "no-cache"
        }

    response = requests.request("POST", url, data=payload, headers=headers)

    # print(response.text)
    d= json.loads(response.text)
    return d["fileId"]

def dummy(request):
    """Responds to any HTTP request.
    Args:
        request (flask.Request): HTTP request object.
    Returns:
        The response text or any set of values that can be turned into a
        Response object using
        `make_response <http://flask.pocoo.org/docs/1.0/api/#flask.Flask.make_response>`.
    """
    if request.method == 'OPTIONS':
        # Allows GET requests from origin https://mydomain.com with
        # Authorization header
        headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST',
            'Access-Control-Allow-Headers': '*',
            'Access-Control-Max-Age': '3600',
            'Access-Control-Allow-Credentials': 'true'
        }
        return ('', 204, headers)

    # Set CORS headers for main requests
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': 'true'
    }

    # request_json = request.get_json()
    mongostr = os.environ.get('MONGOSTR')
    client = pymongo.MongoClient(mongostr)
    db = client["prescrypto"]
    col = db.creadings
    results = []
    maxid = 0
    ts = str(int(time.time()))
    payload = {}
    superpayload = {}


    # if request_json:
    if 'CANCEL' not in form.get('USERID'):
        payload["userid"] = form.get('USERID')
        payload["pulse"] = form.get('HR')
        payload["spo2"] = form.get('spo2')
        payload["temp"] = form.get('temp')
        payload["ts"] = ts
        
        superpayload["patient"] = form.get('patient')
        superpayload["doctor"] = form.get('doctor')
        superpayload["record"] = payload
        fileId = hederainsert(superpayload)
        payload["fileId"] = fileId
  
        result=col.insert_one(payload)

        payload = {}
        col = db.readingchain
        payload["ts"] = ts
        payload['fileId'] = fileId
        result=col.insert_one(payload)


        col = db.currentreadings
        area  = col.find_one({"status": "current"})
        oldpulse = float(area["pulse"])
        newpulse = (oldpulse + float(form.get('HR')))/2.0
        oldspo2 =  float(area["spo2"])
        newspo2 = (oldspo2 + float(form.get('spo2')))/2.0
        col.update_one({"status":"current"}, {"$set":{"pulse":str(newpulse)}})
        col.update_one({"status":"current"}, {"$set":{"spo2":str(newspo2)}})
        area  = col.find_one({"status": "current"})
        superpayload = {}
        superpayload["patient"] = form.get('patient')
        superpayload["doctor"] = form.get('doctor')
        superpayload["record"] = area
        fileId = hederainsert(superpayload) 
    
        col.update_one({"status":"current"}, {"$set":{"fileId":fileId}})

        # oldpop = float(area["steps"])
        # newpop = oldpop+float(form.get('steps'))
        # col.update_one({"status":"current"}, {"$set":{"steps":str(newpop)}})
        # payload = {}
        # payload['ts'] = ts
        # payload['steps'] = str(newpop)
        # print (payload)

        retjson = {}

        retjson['fileId'] = fileId
        retjson['mongoresult'] = "successfully added"

        return json.dumps(retjson)


    retstr = "action not done"

    if request.args and 'message' in request.args:
        return request.args.get('message')
    elif request_json and 'message' in request_json:
        return request_json['message']
    else:
        return retstr
