import os
import pymongo
import json
import time
import requests

def hederainsert(datain):

    url = "https://woodle.ngrok.io/healthRecord"

    payload = json.dumps(datain)
    headers = {
        'Content-Type': "application/json",
        'cache-control': "no-cache"
        }

    response = requests.request("POST", url, data=payload, headers=headers)

    # print(response.text)
    d= json.loads(response.text)
    return d["fileId"]





def dummy(request):
    """Responds to any HTTP request.
    Args:
        request (flask.Request): HTTP request object.
    Returns:
        The response text or any set of values that can be turned into a
        Response object using
        `make_response <http://flask.pocoo.org/docs/1.0/api/#flask.Flask.make_response>`.
    """
    if request.method == 'OPTIONS':
        # Allows GET requests from origin https://mydomain.com with
        # Authorization header
        headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST',
            'Access-Control-Allow-Headers': '*',
            'Access-Control-Max-Age': '3600',
            'Access-Control-Allow-Credentials': 'true'
        }
        return ('', 204, headers)

    # Set CORS headers for main requests
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': 'true'
    }

    request_json = request.get_json()
    mongostr = os.environ.get('MONGOSTR')
    client = pymongo.MongoClient(mongostr)
    db = client["prescrypto"]
    col = db.current
    results = []
    maxid = 0
    ts = str(int(time.time()))
    payload = {}
    superpayload = {}

    # if request_json:
    if 'gsrtarget' in request_json:
        
        payload["type"] = "targets"
        payload["weekstart"] = ts
        payload["gsrtarget"] = request_json['gsrtarget']
        payload["pulsetarget"] = request_json['pulsetarget']
        payload["steptarget"] = request_json['steptarget']
        payload["weighttarget"] = request_json['weighttarget']
        payload["spo2target"] = request_json['spo2target']
        payload["exercisehourstarget"] = request_json['exercisehourstarget']
        payload["sleephourstarget"] = request_json['sleephourstarget']
        # payload["imageUrl"] = request_json['imageUrl']
        # payload["audioUrl"] = request_json['audioUrl']
        # payload["email"] = request_json['email']
        # payload["username"] = request_json['username']
        # payload["password"] = request_json['password']
        superpayload["doctor"] = "5ec04ec9f80f9328703088b0"
        superpayload["patient"] = "5ec04ed9f80f9328703088b1"
        superpayload["record"] = payload
        payload ["fileId"] = hederainsert(superpayload)

        result=col.insert_one(payload)

        retjson = {}

        retjson['fileId'] = payload["fileId"]
        retjson['mongoresult'] = "successfully added"

        return json.dumps(retjson)


    retstr = "action not done"

    if request.args and 'message' in request.args:
        return request.args.get('message')
    elif request_json and 'message' in request_json:
        return request_json['message']
    else:
        return retstr
